﻿using System;

namespace WhatIsInterface
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Car car = new Car();
            //car.Go();

            //Sonata sonata  = new Sonata();
            //sonata.Go();

            //Dog dog = new Dog();
            //dog.Eat();
            //dog.Yelp();
            //dog.Eat();
            //dog.Yelp();
            //dog.Yelp();
            //dog.Yelp();
            //dog.Eat();
            //dog.Yelp();

            //CollectionInfo collectionInfo  = new CollectionInfo();
            //collectionInfo.Sample();

            Poker poker = new Poker();
            poker.PokerGame();
        }
    }
}